//Added by Rikazu
package com.sturdyhelmetgames.roomforchange.screen;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Color;
import com.sturdyhelmetgames.roomforchange.RoomForChangeGame;
import com.sturdyhelmetgames.roomforchange.assets.Assets;
import com.sturdyhelmetgames.roomforchange.assets.FontBig;
import com.sturdyhelmetgames.roomforchange.level.Level;

public class PauseScreen extends Basic2DScreen {

	private final GameScreen gameScreen;
	public final FontBig font = new FontBig(FontBig.FONT_COLOR_WHITE);
	
	public PauseScreen(RoomForChangeGame game, GameScreen gameScreen){
		super(game, 12, 8);
		this.gameScreen = gameScreen;
		Assets.getGameSound(Assets.SOUND_MUSIC).pause();
	}
	
	@Override
	protected void updateScreen(float fixedStep) {
		
		
	}

	@Override
	public void renderScreen(float delta) {
		gameScreen.renderScreen(delta);
		spriteBatch.setProjectionMatrix(camera.combined);
		spriteBatch.begin();
		final Color originalColor = spriteBatch.getColor();
		spriteBatch.setColor(1f, 1f, 1f, 0.5f);
		spriteBatch.draw(Assets.getFullGameObject("black"), -6f, -4f, 12f, 8f);
		spriteBatch.setColor(originalColor);
		
		final float pauseX = camera.position.x;
		final float pauseY = camera.position.y;
		font.draw(spriteBatch, "PAUSED", pauseX - (font.getScale() * 2.5f), pauseY);
		spriteBatch.end();
		
	}
	
	@Override
	public boolean keyDown(int keycode) {
		if(keycode == Keys.P){
			Assets.getGameSound(Assets.SOUND_MUSIC).resume();
			Gdx.input.setInputProcessor(gameScreen);
			game.setScreen(gameScreen);
		}
		return super.keyDown(keycode);
	}

}
