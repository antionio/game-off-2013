package com.sturdyhelmetgames.roomforchange.level;

import org.junit.Test;

public class LabyrinthPieceTest {

	@Test
	public void testCreateLabyrinthPiece() {
//		final LevelTileType[][] tileTypes = new LevelTileType[PieceTemplate.WIDTH][PieceTemplate.HEIGHT];
//		for (int x = 0; x < PieceTemplate.WIDTH; x++) {
//			for (int y = 0; y < PieceTemplate.HEIGHT; y++) {
//				tileTypes[x][y] = LevelTileType.GROUND;
//			}
//		}
//
//		PieceTemplate pieceTemplate = Mockito.mock(PieceTemplate.class);
//		RoomTemplate roomObjectTemplate = Mockito.mock(RoomTemplate.class);
//		Mockito.when(pieceTemplate.getTileTypes()).thenReturn(tileTypes);
//
//		LabyrinthPiece piece = new LabyrinthPiece(pieceTemplate,
//				roomObjectTemplate, 0, new Level());
//		assertNotNull(piece);
//		assertEquals(PieceTemplate.WIDTH, piece.getTiles().length);
//		assertEquals(PieceTemplate.HEIGHT, piece.getTiles()[0].length);
//		for (int x = 0; x < PieceTemplate.WIDTH; x++) {
//			for (int y = 0; y < PieceTemplate.HEIGHT; y++) {
//				assertEquals(LevelTileType.GROUND, piece.getTiles()[x][y].type);
//			}
//		}
//
//		Mockito.verify(pieceTemplate);
		// Mockito.verify(roomObjectTemplate);

	}
}
